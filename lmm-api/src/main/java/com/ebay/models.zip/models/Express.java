package team.lmm.models;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author
 */
@Data
public class Express implements Serializable {
    private Integer id;

    private String number;

    private Date modifyTime;

    private Integer status;

    private String type;

    private Integer deliveryStatus;

    private Integer httpCode;

    private String msg;

    private String detail;

    private ExpressCompany company;

    private static final long serialVersionUID = 1L;

}