package team.lmm.models;

import lombok.Data;
import team.lmm.common.Property;

/**
 * @author: jf <for1988@126.com>
 * @date: 2016/12/17
 */

@Data
public class Shop {

    private String shopId;
    private String shopName;
    private String address;
    private String type;
    private String phone;
    private String logo;
    private String jingdu;
    private String weidu;
    private String notice;
    private String otherInfo;
    private String typeId;

    private double createUser;
    private String createTime;
    private String modifyTime;
    private double modifyUser;

    private String status; //状态，1：可用，2：锁定
    private String province;
    private String city;
    private String county;
    private String busiarea;
    private String cityname;
    private Integer shopFlag;
    private Integer hotFlag;
    private Double ticketBear;
    private String videoCover;

    private Integer onLiveNum;

    private String brand;
    private Integer brandSet;

    private String cityCode;

    private String story;
    private String ownerName;
    private String ownerLogo = Property.getConfig().getDefaultHead();

    private Integer vipTag;

    private Integer starTimes;

    private Integer starFlag;

    private Double distance;
}
