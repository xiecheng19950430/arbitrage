package team.lmm.models;

import lombok.Data;

/**
 * Created by ldm on 2017/5/3.
 */
@Data
public class Area {
    Integer id;
    String name;
    Integer level;
    Integer type;
    Integer index;
    Integer disable;
    String code;
    Integer parentId;
    Integer sortNo;
    String category;
}
