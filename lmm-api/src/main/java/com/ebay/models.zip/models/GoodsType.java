package team.lmm.models;

import lombok.Data;

/**
 * Created by ldm on 2017/2/28.
 */
@Data
public class GoodsType {
    private String id;
    private String code;
    private String name;
    private String sortNO;
    private Integer createUser;
    private String createTime;
    private Integer modifyUser;
    private String modifyTime;
    private String typeFlag;
}
