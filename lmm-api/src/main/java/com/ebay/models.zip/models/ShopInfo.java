package team.lmm.models;

import lombok.Data;

import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.Date;

/**
 * @author
 */
@Data
public class ShopInfo implements Serializable {
    private Integer id;

    private String title;

    private String tag;

    private Integer createUser;

    private String shopId;

    private Integer viewTimes;

    private Integer feedbackTimes;

    private Integer starTimes;

    private String img;

    @Size(max = 1000, message = "简述内容不能超过1000字")
    private String tips;

    private Date createTime;

    private Integer deleteFlag;

    private Date deleteTime;

    private Integer deleteBy;

    private Integer type;

    private String content;

    private Integer starFlag;

    private Integer homeTop;

    private static final long serialVersionUID = 1L;


}