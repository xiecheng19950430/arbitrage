package team.lmm.models;

import lombok.Data;

/**
 * Created by ldm on 2017/4/10.
 */
@Data
public class ShoppingCategoryItem {
    private Integer id;
    private Integer categoryId;
    private String targetId;
    private String pic;
    private Integer sort;
    private ShoppingCategory shoppingCategory;
}
