package team.lmm.models;

import lombok.Data;

/**
 * Created by ldm on 2017/4/8.
 */
@Data
public class InkeLogin {
    private String guid;
    private Integer uid;
}
