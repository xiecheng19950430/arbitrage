package team.lmm.models;

import lombok.Data;

/**
 * @author: jf <for1988@126.com>
 * @date: 2016/12/17
 */
@Data
public class Goods {

    private String goodsId;
    private String name;
    private Double price;
    private Double discountPrice;
    private Integer soldOut;
    private String shopId;
    private String img;
    private String tag;
    private String detail;
    private Integer skn;
    private String code;
    private String colors;
    private String sizes;
    private String remark;
    private Integer stock;
    private String createTime;
    private String modifyTime;
    private String goodsTypeId;
    private Integer sortNo;
    private String limitNum;
    private String ifHome;
    private String seriesName;
    private Integer deleteFlag;
    private Integer homeSort;

    private Integer scope;
    private Integer useScope;

    private String brand;

    private Integer raffleTicket;
}
