package team.lmm.models;

import lombok.Data;
import team.lmm.common.Property;

/**
 * Created by jf on 2016/12/4.
 */

@Data
public class User {

    Integer userId;
    String mobile;
    String username;
    String password;
    Integer sex = 0;
    String portrait = Property.getConfig().getDefaultHead();
    String birthday;
    String realName;
    String isSys;
    String tel;
    String wxId;
    String qqId;

    Integer fromUid;
    Integer virtualMoney;
    Integer point;
    Integer raffleTicket;
}
