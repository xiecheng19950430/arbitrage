package team.lmm.models;

import lombok.Data;

import java.util.List;

/**
 * Created by ldm on 2017/8/8.
 */
@Data
public class TradeDetail extends Trade {
    private List<OrderDetail> orderDetails;
}
