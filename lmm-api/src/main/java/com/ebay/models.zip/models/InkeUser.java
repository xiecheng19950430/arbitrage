package team.lmm.models;

import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * Created by ldm on 2017/4/5.
 */
@Data
public class InkeUser {
    Integer id;
    Integer uid;
    String name;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    Date createTime;
    String cityName;
    Integer workStatus;
    String cityCode;
}
