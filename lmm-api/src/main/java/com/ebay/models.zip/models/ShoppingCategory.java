package team.lmm.models;

import lombok.Data;

/**
 * Created by ldm on 2017/4/10.
 */
@Data
public class ShoppingCategory {
    private Integer id;
    private String name;
    private String viewType;
    private Integer sort;
    private Integer disable;
    private String url;
    private String img;
    private String tip;
}
