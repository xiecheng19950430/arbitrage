package team.lmm.models;

import lombok.Data;

/**
 * Created by ldm on 2017/9/6.
 */
@Data
public class GoodsExtend extends Goods {
    private Shop shop;
}
