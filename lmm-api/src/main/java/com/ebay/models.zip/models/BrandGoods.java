package team.lmm.models;

import lombok.Data;

import java.util.Date;

/**
 * Created by ldm on 2017/4/24.
 */
@Data
public class BrandGoods {
    private Integer brandId;
    private String goodsId;
    private Integer sort;
    private Date createAt;

}
