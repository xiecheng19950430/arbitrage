package team.lmm.models;

import lombok.Data;

/**
 * @author: jf <for1988@126.com>
 * @date: 2016/12/17
 */
@Data
public class ShoppingGoods {

    private ShoppingCart shoppingCart;

    private Goods goods;

    private Shop shop;

    private GoodsStock goodsStock;
}
