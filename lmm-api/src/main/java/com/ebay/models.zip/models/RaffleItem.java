package team.lmm.models;

import lombok.Data;

import java.io.Serializable;

/**
 * @author
 */
@Data
public class RaffleItem implements Serializable {
    private Integer id;

    private Integer raffleId;

    private String itemName;

    private String itemImg;

    /**
     * 0:积分;1:真豆;
     */
    private Integer itemType;

    private String itemValue;

    private Integer share;

    private Integer weight;

    private static final long serialVersionUID = 1L;


}