package team.lmm.models;

import lombok.Data;

/**
 * @author: jf <for1988@126.com>
 * @date: 2016/12/21
 */

@Data
public class TradeOrder {

    private Trade trade;
    private Order order;

    public TradeOrder() {
    }

    public TradeOrder(Trade trade, Order order) {
        this.trade = trade;
        this.order = order;
    }
}
