package team.lmm.models;

import lombok.Data;

import java.util.Date;

/**
 * @author: jf <for1988@126.com>
 * @date: 2016/12/16
 */

@Data
public class ShoppingCart {
    private Integer id;
    private String goodsId;
    private Integer sku;
    private Integer skn;
    private Integer num;
    private Integer state;
    private String selected;
    private Integer uid;
    private String shoppingKey;
    private String color;
    private String size;
    private Date createdAt;
    private GoodsStock goodsStock;
}
