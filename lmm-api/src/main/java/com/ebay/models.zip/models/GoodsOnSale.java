package team.lmm.models;

import lombok.Data;

/**
 * Created by ldm on 2017/4/6.
 */
@Data
public class GoodsOnSale {
    private Integer id;
    private String goodsId;
    private Integer auditStatus;
    private Integer enable;
    private Integer sort;
    private Goods goods;
    private Shop shop;
}
