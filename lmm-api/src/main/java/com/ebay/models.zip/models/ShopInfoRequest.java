package team.lmm.models;

import lombok.Data;

/**
 * Created by ldm on 2017/8/14.
 */
@Data
public class ShopInfoRequest extends ShopInfo {
    private String token;
}
