package team.lmm.models;

import lombok.Data;

/**
 * Created by ldm on 2017/4/7.
 */
@Data
public class CityDic {
    private String alias;
    private String realName;
}
