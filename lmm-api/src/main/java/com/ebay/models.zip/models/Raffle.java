package team.lmm.models;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author 
 */
@Data
public class Raffle implements Serializable {
    private Integer id;

    private String name;

    private Integer ticketCost;

    private String rule;

    private Integer disable;

    private String img;

    private Date createTime;

    private Date modifyTime;

    private static final long serialVersionUID = 1L;


}