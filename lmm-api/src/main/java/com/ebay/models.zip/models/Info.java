package team.lmm.models;

import lombok.Data;

import java.util.Date;

/**
 * Created by ldm on 2017/4/8.
 */
@Data
public class Info {
    private Integer infoId;
    private Date createDate;
    private Date updateDate;
    private String categoryName;
    private String topic;
    private String content;
    private String url;
    private String headImage;
    private String infoDes;
    private String city;
    private Integer categoryId;
}
