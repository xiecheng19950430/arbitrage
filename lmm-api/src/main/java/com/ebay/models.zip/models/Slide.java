package team.lmm.models;

import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by ldm on 2017/3/22.
 */
@Data
public class Slide implements Serializable {
    private String id;
    private String title;
    private String banner;
    private String href;
    private String description;
    private String sort;
    private String display;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date updateTime;
    private String type;
    private String position;
    private String province;
    private String city;
    private String county;
    private String cityName;
    private String cityCode;
}
