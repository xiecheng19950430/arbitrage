package team.lmm.models;

import lombok.Data;

/**
 * Created by chenliang on 2017/1/11.
 */
@Data
public class ShopMoneyRecordAccount {

    private Integer recordAccountId;
    private String type;
    private String accountName;
    private String bankId;
    private String bankName;
    private String bankDetail;
    private String alipay;
    private String weixin;
    private String shopId;
    private String state;


}
