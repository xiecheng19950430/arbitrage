package team.lmm.models;

import lombok.Data;

/**
 * Created by ldm on 2017/4/24.
 */
@Data
public class BrandApply {
    private Integer id;
    private String name;
    private String logo;
    private Integer status;
    private String description;
    private String shopId;
}
