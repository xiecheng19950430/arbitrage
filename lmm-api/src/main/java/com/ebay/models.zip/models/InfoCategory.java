package team.lmm.models;

import lombok.Data;

/**
 * Created by ldm on 2017/4/8.
 */
@Data
public class InfoCategory {
    private Integer categoryId;
    private String categoryName;
    private Integer orderNum;
    private Integer pCategoryId;
}
