package team.lmm.models;

import java.util.ArrayList;
import java.util.List;

public class GoodsCategoryExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private Integer limit;

    private Integer offset;

    public GoodsCategoryExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andCatIdIsNull() {
            addCriterion("cat_id is null");
            return (Criteria) this;
        }

        public Criteria andCatIdIsNotNull() {
            addCriterion("cat_id is not null");
            return (Criteria) this;
        }

        public Criteria andCatIdEqualTo(Integer value) {
            addCriterion("cat_id =", value, "catId");
            return (Criteria) this;
        }

        public Criteria andCatIdNotEqualTo(Integer value) {
            addCriterion("cat_id <>", value, "catId");
            return (Criteria) this;
        }

        public Criteria andCatIdGreaterThan(Integer value) {
            addCriterion("cat_id >", value, "catId");
            return (Criteria) this;
        }

        public Criteria andCatIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("cat_id >=", value, "catId");
            return (Criteria) this;
        }

        public Criteria andCatIdLessThan(Integer value) {
            addCriterion("cat_id <", value, "catId");
            return (Criteria) this;
        }

        public Criteria andCatIdLessThanOrEqualTo(Integer value) {
            addCriterion("cat_id <=", value, "catId");
            return (Criteria) this;
        }

        public Criteria andCatIdIn(List<Integer> values) {
            addCriterion("cat_id in", values, "catId");
            return (Criteria) this;
        }

        public Criteria andCatIdNotIn(List<Integer> values) {
            addCriterion("cat_id not in", values, "catId");
            return (Criteria) this;
        }

        public Criteria andCatIdBetween(Integer value1, Integer value2) {
            addCriterion("cat_id between", value1, value2, "catId");
            return (Criteria) this;
        }

        public Criteria andCatIdNotBetween(Integer value1, Integer value2) {
            addCriterion("cat_id not between", value1, value2, "catId");
            return (Criteria) this;
        }

        public Criteria andCatNameIsNull() {
            addCriterion("cat_name is null");
            return (Criteria) this;
        }

        public Criteria andCatNameIsNotNull() {
            addCriterion("cat_name is not null");
            return (Criteria) this;
        }

        public Criteria andCatNameEqualTo(String value) {
            addCriterion("cat_name =", value, "catName");
            return (Criteria) this;
        }

        public Criteria andCatNameNotEqualTo(String value) {
            addCriterion("cat_name <>", value, "catName");
            return (Criteria) this;
        }

        public Criteria andCatNameGreaterThan(String value) {
            addCriterion("cat_name >", value, "catName");
            return (Criteria) this;
        }

        public Criteria andCatNameGreaterThanOrEqualTo(String value) {
            addCriterion("cat_name >=", value, "catName");
            return (Criteria) this;
        }

        public Criteria andCatNameLessThan(String value) {
            addCriterion("cat_name <", value, "catName");
            return (Criteria) this;
        }

        public Criteria andCatNameLessThanOrEqualTo(String value) {
            addCriterion("cat_name <=", value, "catName");
            return (Criteria) this;
        }

        public Criteria andCatNameLike(String value) {
            addCriterion("cat_name like", value, "catName");
            return (Criteria) this;
        }

        public Criteria andCatNameNotLike(String value) {
            addCriterion("cat_name not like", value, "catName");
            return (Criteria) this;
        }

        public Criteria andCatNameIn(List<String> values) {
            addCriterion("cat_name in", values, "catName");
            return (Criteria) this;
        }

        public Criteria andCatNameNotIn(List<String> values) {
            addCriterion("cat_name not in", values, "catName");
            return (Criteria) this;
        }

        public Criteria andCatNameBetween(String value1, String value2) {
            addCriterion("cat_name between", value1, value2, "catName");
            return (Criteria) this;
        }

        public Criteria andCatNameNotBetween(String value1, String value2) {
            addCriterion("cat_name not between", value1, value2, "catName");
            return (Criteria) this;
        }

        public Criteria andEnableIsNull() {
            addCriterion("enable is null");
            return (Criteria) this;
        }

        public Criteria andEnableIsNotNull() {
            addCriterion("enable is not null");
            return (Criteria) this;
        }

        public Criteria andEnableEqualTo(Byte value) {
            addCriterion("enable =", value, "enable");
            return (Criteria) this;
        }

        public Criteria andEnableNotEqualTo(Byte value) {
            addCriterion("enable <>", value, "enable");
            return (Criteria) this;
        }

        public Criteria andEnableGreaterThan(Byte value) {
            addCriterion("enable >", value, "enable");
            return (Criteria) this;
        }

        public Criteria andEnableGreaterThanOrEqualTo(Byte value) {
            addCriterion("enable >=", value, "enable");
            return (Criteria) this;
        }

        public Criteria andEnableLessThan(Byte value) {
            addCriterion("enable <", value, "enable");
            return (Criteria) this;
        }

        public Criteria andEnableLessThanOrEqualTo(Byte value) {
            addCriterion("enable <=", value, "enable");
            return (Criteria) this;
        }

        public Criteria andEnableIn(List<Byte> values) {
            addCriterion("enable in", values, "enable");
            return (Criteria) this;
        }

        public Criteria andEnableNotIn(List<Byte> values) {
            addCriterion("enable not in", values, "enable");
            return (Criteria) this;
        }

        public Criteria andEnableBetween(Byte value1, Byte value2) {
            addCriterion("enable between", value1, value2, "enable");
            return (Criteria) this;
        }

        public Criteria andEnableNotBetween(Byte value1, Byte value2) {
            addCriterion("enable not between", value1, value2, "enable");
            return (Criteria) this;
        }

        public Criteria andParentIdIsNull() {
            addCriterion("parent_id is null");
            return (Criteria) this;
        }

        public Criteria andParentIdIsNotNull() {
            addCriterion("parent_id is not null");
            return (Criteria) this;
        }

        public Criteria andParentIdEqualTo(Integer value) {
            addCriterion("parent_id =", value, "parentId");
            return (Criteria) this;
        }

        public Criteria andParentIdNotEqualTo(Integer value) {
            addCriterion("parent_id <>", value, "parentId");
            return (Criteria) this;
        }

        public Criteria andParentIdGreaterThan(Integer value) {
            addCriterion("parent_id >", value, "parentId");
            return (Criteria) this;
        }

        public Criteria andParentIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("parent_id >=", value, "parentId");
            return (Criteria) this;
        }

        public Criteria andParentIdLessThan(Integer value) {
            addCriterion("parent_id <", value, "parentId");
            return (Criteria) this;
        }

        public Criteria andParentIdLessThanOrEqualTo(Integer value) {
            addCriterion("parent_id <=", value, "parentId");
            return (Criteria) this;
        }

        public Criteria andParentIdIn(List<Integer> values) {
            addCriterion("parent_id in", values, "parentId");
            return (Criteria) this;
        }

        public Criteria andParentIdNotIn(List<Integer> values) {
            addCriterion("parent_id not in", values, "parentId");
            return (Criteria) this;
        }

        public Criteria andParentIdBetween(Integer value1, Integer value2) {
            addCriterion("parent_id between", value1, value2, "parentId");
            return (Criteria) this;
        }

        public Criteria andParentIdNotBetween(Integer value1, Integer value2) {
            addCriterion("parent_id not between", value1, value2, "parentId");
            return (Criteria) this;
        }

        public Criteria andIsTypeIsNull() {
            addCriterion("is_type is null");
            return (Criteria) this;
        }

        public Criteria andIsTypeIsNotNull() {
            addCriterion("is_type is not null");
            return (Criteria) this;
        }

        public Criteria andIsTypeEqualTo(Integer value) {
            addCriterion("is_type =", value, "isType");
            return (Criteria) this;
        }

        public Criteria andIsTypeNotEqualTo(Integer value) {
            addCriterion("is_type <>", value, "isType");
            return (Criteria) this;
        }

        public Criteria andIsTypeGreaterThan(Integer value) {
            addCriterion("is_type >", value, "isType");
            return (Criteria) this;
        }

        public Criteria andIsTypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("is_type >=", value, "isType");
            return (Criteria) this;
        }

        public Criteria andIsTypeLessThan(Integer value) {
            addCriterion("is_type <", value, "isType");
            return (Criteria) this;
        }

        public Criteria andIsTypeLessThanOrEqualTo(Integer value) {
            addCriterion("is_type <=", value, "isType");
            return (Criteria) this;
        }

        public Criteria andIsTypeIn(List<Integer> values) {
            addCriterion("is_type in", values, "isType");
            return (Criteria) this;
        }

        public Criteria andIsTypeNotIn(List<Integer> values) {
            addCriterion("is_type not in", values, "isType");
            return (Criteria) this;
        }

        public Criteria andIsTypeBetween(Integer value1, Integer value2) {
            addCriterion("is_type between", value1, value2, "isType");
            return (Criteria) this;
        }

        public Criteria andIsTypeNotBetween(Integer value1, Integer value2) {
            addCriterion("is_type not between", value1, value2, "isType");
            return (Criteria) this;
        }

        public Criteria andCatCodeIsNull() {
            addCriterion("cat_code is null");
            return (Criteria) this;
        }

        public Criteria andCatCodeIsNotNull() {
            addCriterion("cat_code is not null");
            return (Criteria) this;
        }

        public Criteria andCatCodeEqualTo(String value) {
            addCriterion("cat_code =", value, "catCode");
            return (Criteria) this;
        }

        public Criteria andCatCodeNotEqualTo(String value) {
            addCriterion("cat_code <>", value, "catCode");
            return (Criteria) this;
        }

        public Criteria andCatCodeGreaterThan(String value) {
            addCriterion("cat_code >", value, "catCode");
            return (Criteria) this;
        }

        public Criteria andCatCodeGreaterThanOrEqualTo(String value) {
            addCriterion("cat_code >=", value, "catCode");
            return (Criteria) this;
        }

        public Criteria andCatCodeLessThan(String value) {
            addCriterion("cat_code <", value, "catCode");
            return (Criteria) this;
        }

        public Criteria andCatCodeLessThanOrEqualTo(String value) {
            addCriterion("cat_code <=", value, "catCode");
            return (Criteria) this;
        }

        public Criteria andCatCodeLike(String value) {
            addCriterion("cat_code like", value, "catCode");
            return (Criteria) this;
        }

        public Criteria andCatCodeNotLike(String value) {
            addCriterion("cat_code not like", value, "catCode");
            return (Criteria) this;
        }

        public Criteria andCatCodeIn(List<String> values) {
            addCriterion("cat_code in", values, "catCode");
            return (Criteria) this;
        }

        public Criteria andCatCodeNotIn(List<String> values) {
            addCriterion("cat_code not in", values, "catCode");
            return (Criteria) this;
        }

        public Criteria andCatCodeBetween(String value1, String value2) {
            addCriterion("cat_code between", value1, value2, "catCode");
            return (Criteria) this;
        }

        public Criteria andCatCodeNotBetween(String value1, String value2) {
            addCriterion("cat_code not between", value1, value2, "catCode");
            return (Criteria) this;
        }

        public Criteria andCatIndexIsNull() {
            addCriterion("cat_index is null");
            return (Criteria) this;
        }

        public Criteria andCatIndexIsNotNull() {
            addCriterion("cat_index is not null");
            return (Criteria) this;
        }

        public Criteria andCatIndexEqualTo(Integer value) {
            addCriterion("cat_index =", value, "catIndex");
            return (Criteria) this;
        }

        public Criteria andCatIndexNotEqualTo(Integer value) {
            addCriterion("cat_index <>", value, "catIndex");
            return (Criteria) this;
        }

        public Criteria andCatIndexGreaterThan(Integer value) {
            addCriterion("cat_index >", value, "catIndex");
            return (Criteria) this;
        }

        public Criteria andCatIndexGreaterThanOrEqualTo(Integer value) {
            addCriterion("cat_index >=", value, "catIndex");
            return (Criteria) this;
        }

        public Criteria andCatIndexLessThan(Integer value) {
            addCriterion("cat_index <", value, "catIndex");
            return (Criteria) this;
        }

        public Criteria andCatIndexLessThanOrEqualTo(Integer value) {
            addCriterion("cat_index <=", value, "catIndex");
            return (Criteria) this;
        }

        public Criteria andCatIndexIn(List<Integer> values) {
            addCriterion("cat_index in", values, "catIndex");
            return (Criteria) this;
        }

        public Criteria andCatIndexNotIn(List<Integer> values) {
            addCriterion("cat_index not in", values, "catIndex");
            return (Criteria) this;
        }

        public Criteria andCatIndexBetween(Integer value1, Integer value2) {
            addCriterion("cat_index between", value1, value2, "catIndex");
            return (Criteria) this;
        }

        public Criteria andCatIndexNotBetween(Integer value1, Integer value2) {
            addCriterion("cat_index not between", value1, value2, "catIndex");
            return (Criteria) this;
        }

        public Criteria andSortIsNull() {
            addCriterion("sort is null");
            return (Criteria) this;
        }

        public Criteria andSortIsNotNull() {
            addCriterion("sort is not null");
            return (Criteria) this;
        }

        public Criteria andSortEqualTo(Integer value) {
            addCriterion("sort =", value, "sort");
            return (Criteria) this;
        }

        public Criteria andSortNotEqualTo(Integer value) {
            addCriterion("sort <>", value, "sort");
            return (Criteria) this;
        }

        public Criteria andSortGreaterThan(Integer value) {
            addCriterion("sort >", value, "sort");
            return (Criteria) this;
        }

        public Criteria andSortGreaterThanOrEqualTo(Integer value) {
            addCriterion("sort >=", value, "sort");
            return (Criteria) this;
        }

        public Criteria andSortLessThan(Integer value) {
            addCriterion("sort <", value, "sort");
            return (Criteria) this;
        }

        public Criteria andSortLessThanOrEqualTo(Integer value) {
            addCriterion("sort <=", value, "sort");
            return (Criteria) this;
        }

        public Criteria andSortIn(List<Integer> values) {
            addCriterion("sort in", values, "sort");
            return (Criteria) this;
        }

        public Criteria andSortNotIn(List<Integer> values) {
            addCriterion("sort not in", values, "sort");
            return (Criteria) this;
        }

        public Criteria andSortBetween(Integer value1, Integer value2) {
            addCriterion("sort between", value1, value2, "sort");
            return (Criteria) this;
        }

        public Criteria andSortNotBetween(Integer value1, Integer value2) {
            addCriterion("sort not between", value1, value2, "sort");
            return (Criteria) this;
        }

        public Criteria andCatImgIsNull() {
            addCriterion("cat_img is null");
            return (Criteria) this;
        }

        public Criteria andCatImgIsNotNull() {
            addCriterion("cat_img is not null");
            return (Criteria) this;
        }

        public Criteria andCatImgEqualTo(String value) {
            addCriterion("cat_img =", value, "catImg");
            return (Criteria) this;
        }

        public Criteria andCatImgNotEqualTo(String value) {
            addCriterion("cat_img <>", value, "catImg");
            return (Criteria) this;
        }

        public Criteria andCatImgGreaterThan(String value) {
            addCriterion("cat_img >", value, "catImg");
            return (Criteria) this;
        }

        public Criteria andCatImgGreaterThanOrEqualTo(String value) {
            addCriterion("cat_img >=", value, "catImg");
            return (Criteria) this;
        }

        public Criteria andCatImgLessThan(String value) {
            addCriterion("cat_img <", value, "catImg");
            return (Criteria) this;
        }

        public Criteria andCatImgLessThanOrEqualTo(String value) {
            addCriterion("cat_img <=", value, "catImg");
            return (Criteria) this;
        }

        public Criteria andCatImgLike(String value) {
            addCriterion("cat_img like", value, "catImg");
            return (Criteria) this;
        }

        public Criteria andCatImgNotLike(String value) {
            addCriterion("cat_img not like", value, "catImg");
            return (Criteria) this;
        }

        public Criteria andCatImgIn(List<String> values) {
            addCriterion("cat_img in", values, "catImg");
            return (Criteria) this;
        }

        public Criteria andCatImgNotIn(List<String> values) {
            addCriterion("cat_img not in", values, "catImg");
            return (Criteria) this;
        }

        public Criteria andCatImgBetween(String value1, String value2) {
            addCriterion("cat_img between", value1, value2, "catImg");
            return (Criteria) this;
        }

        public Criteria andCatImgNotBetween(String value1, String value2) {
            addCriterion("cat_img not between", value1, value2, "catImg");
            return (Criteria) this;
        }
    }

    /**
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}