package team.lmm.models;

import lombok.Data;

/**
 * Created by ldm on 2017/3/15.
 */
@Data
public class TicketPackageDetail {
    private String id;
    private String packageId;
    private Integer ticketId;
}
