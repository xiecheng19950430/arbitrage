package team.lmm.models;

import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * Created by ldm on 2017/4/5.
 */
@Data
public class InkeShopVideo {
    Integer id;
    String shopId;
    String nick;
    Integer uid;
    Integer gender;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    Date createTime;
    Integer level;
    String city;
    String name;
    String portrait;
    Integer onlineUsers;
    String liveId;
    Integer enable;
}
