package team.lmm.models;

import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * Created by ldm on 2017/3/15.
 */
@Data
public class Activity {
    private String id;
    private Integer activityType;
    private String name;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date start;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date end;
    private Integer status;
    private String area;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createAt;
    private String description;
    private String img;
    private String url;
    private String cityCode;
}
