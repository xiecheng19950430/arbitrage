package team.lmm.models;

import lombok.Data;

/**
 * @author: jf <for1988@126.com>
 * @date: 2016/12/19
 */

@Data
public class Order {

    private String id;
    private Integer uid;
    private String shopId;
    private Double price;
    private Integer scope;
    private Integer state;
    private String createdAt;
    private String remark;
    private Integer isPay;
    private String orderNo;
    private String payType;
    private String user;
    private String address;
    private String phone;

    private Integer tradeId;
    private Integer type = 0;
    private String commentTag;

    private String userNick;

    private Double payInfact;
    private Double platformDiscount;
    private Double vmDiscount;

    private Integer couponId;
    private Double platformBear;

    private String expressNo;
    private String expressType;

    private String sendAt;
    private Integer sendUser;

    private String endAt;


}
