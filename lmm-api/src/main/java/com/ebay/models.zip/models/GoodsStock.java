package team.lmm.models;

import lombok.Data;

/**
 * @author: jf <for1988@126.com>
 * @date: 2016/12/16
 */

@Data
public class GoodsStock {

    private String stockId;
    private String goodsId;
    private String color;
    private String size;
    private Integer stock;
    private Integer sku;
    private Integer skn;
}
