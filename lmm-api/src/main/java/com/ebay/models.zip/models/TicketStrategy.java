package team.lmm.models;

import lombok.Data;

/**
 * Created by ldm on 2017/3/13.
 */
@Data
public class TicketStrategy {
    private String id;
    private Integer getRangeStart;
    private Integer getRangeEnd;
    private String name;
    private String area;
}
