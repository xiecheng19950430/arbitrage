package team.lmm.models;

import lombok.Data;

/**
 * @author: jf <for1988@126.com>
 * @date: 2016/12/20
 */

@Data
public class OrderGoods {

    private String id;
    private String orderId;
    private String goodsId;
    private String code;
    private String name;
    private Double price;
    private Integer num;
    private Double totalPrice;
    private Double marketPrice;
    private String unit;
    private String img;
    private String size;
    private String color;

    private Integer scope;
    private Integer useScope;

    private Integer raffleTicket;
}
