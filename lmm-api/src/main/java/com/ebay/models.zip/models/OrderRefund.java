package team.lmm.models;

import lombok.Data;

import java.util.Date;

/**
 * @author: jf <for1988@126.com>
 * @date: 2017/1/25
 */

@Data
public class OrderRefund {

    private Integer id;
    private String orderId;
    private Integer state;
    private String reason;
    private Integer amount;
    private Date createdAt;
    private Date updatedAt;
    private Integer type;
    private Double platformDiscount;
    private Double vmDiscount;
    private Integer scope;
}
