package team.lmm.models;

import lombok.Data;

import java.util.List;

/**
 * @author: jf <for1988@126.com>
 * @date: 2016/12/26
 */
@Data
public class OrderDetail extends Order {

    private Shop shop;
    private List<OrderGoods> goods;
}
