package team.lmm.models;

import java.io.Serializable;

/**
 * @author 
 */
public class ShopVip implements Serializable {
    private Integer id;

    private String name;

    private Double price;

    private String description;

    private Integer defaultFlag;

    private Integer enable;

    private String rightConfig;

    private static final long serialVersionUID = 1L;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getDefaultFlag() {
        return defaultFlag;
    }

    public void setDefaultFlag(Integer defaultFlag) {
        this.defaultFlag = defaultFlag;
    }

    public Integer getEnable() {
        return enable;
    }

    public void setEnable(Integer enable) {
        this.enable = enable;
    }

    public String getRightConfig() {
        return rightConfig;
    }

    public void setRightConfig(String rightConfig) {
        this.rightConfig = rightConfig;
    }
}