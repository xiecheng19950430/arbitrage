package team.lmm.models;

import lombok.Data;

/**
 * @author: jf <for1988@126.com>
 * @date: 2016/12/17
 */
@Data
public class ShoppingKey {

    private Integer id;
    private Integer uid;
    private String shoppingKey;
}
