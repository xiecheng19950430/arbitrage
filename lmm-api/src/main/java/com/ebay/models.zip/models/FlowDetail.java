package team.lmm.models;

import java.io.Serializable;
import java.util.Date;

/**
 * @author 
 */
public class FlowDetail implements Serializable {
    private Integer id;

    private Integer flowId;

    private Integer consignationId;

    private Integer operateUid;

    private String operateRole;

    private Date createAt;

    private String desc;

    /**
     * 0:提交;10:接受;
     */
    private Integer operateType;

    private static final long serialVersionUID = 1L;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getFlowId() {
        return flowId;
    }

    public void setFlowId(Integer flowId) {
        this.flowId = flowId;
    }

    public Integer getConsignationId() {
        return consignationId;
    }

    public void setConsignationId(Integer consignationId) {
        this.consignationId = consignationId;
    }

    public Integer getOperateUid() {
        return operateUid;
    }

    public void setOperateUid(Integer operateUid) {
        this.operateUid = operateUid;
    }

    public String getOperateRole() {
        return operateRole;
    }

    public void setOperateRole(String operateRole) {
        this.operateRole = operateRole;
    }

    public Date getCreateAt() {
        return createAt;
    }

    public void setCreateAt(Date createAt) {
        this.createAt = createAt;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public Integer getOperateType() {
        return operateType;
    }

    public void setOperateType(Integer operateType) {
        this.operateType = operateType;
    }
}