package team.lmm.models;

import java.io.Serializable;

/**
 * @author 
 */
public class AgentPay implements Serializable {
    private Integer id;

    private Integer batchCount;

    private Double batchAmount;

    /**
     * 0加急1普通
     */
    private Integer payType;

    private String resultCode;

    private String resultMsg;

    private String content;

    private static final long serialVersionUID = 1L;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getBatchCount() {
        return batchCount;
    }

    public void setBatchCount(Integer batchCount) {
        this.batchCount = batchCount;
    }

    public Double getBatchAmount() {
        return batchAmount;
    }

    public void setBatchAmount(Double batchAmount) {
        this.batchAmount = batchAmount;
    }

    public Integer getPayType() {
        return payType;
    }

    public void setPayType(Integer payType) {
        this.payType = payType;
    }

    public String getResultCode() {
        return resultCode;
    }

    public void setResultCode(String resultCode) {
        this.resultCode = resultCode;
    }

    public String getResultMsg() {
        return resultMsg;
    }

    public void setResultMsg(String resultMsg) {
        this.resultMsg = resultMsg;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}