package team.lmm.models;

import lombok.Data;
import team.lmm.common.Property;

/**
 * Created by ldm on 2017/4/24.
 */
@Data
public class Brand {


    private Integer id;
    private String name;
    private String logo = Property.getConfig().getDefaultBrandLogo();
    private Integer sort;
    private String description;
    private Integer level;
    private String tip;
}
