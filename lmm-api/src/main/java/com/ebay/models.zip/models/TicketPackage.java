package team.lmm.models;

import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * Created by ldm on 2017/3/18.
 */
@Data
public class TicketPackage {
    String id;
    Integer num;
    String name;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    Date createAt;
    Integer status;
    Integer deleteFlag;
    String activityId;
    Integer money;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    Date start;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    Date end;
}
