package team.lmm.models;

import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * Created by ldm on 2017/4/12.
 */
@Data
public class Feedback {
    private Integer id;
    private Integer uid;
    private String content;
    private String address;
    private Double lat;
    private Double lng;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;
    private Integer type;
}
