package team.lmm.models;

import lombok.Data;

/**
 * @author: jf <for1988@126.com>
 * @date: 2016/12/19
 */
@Data
public class Address {

    private String id;
    private Integer uid;
    private String province;
    private String city;
    private String area;
    private String address;
    private String user;
    private String phone;
    private Integer isDefault;

}
