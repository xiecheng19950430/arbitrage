package team.lmm.models;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author 
 */
@Data
public class RaffleLog implements Serializable {
    private Integer id;

    private Integer uid;

    private Integer raffleId;

    private Integer raffleItemId;

    private String itemName;

    private Integer itemType;

    private String itemValue;

    private String description;

    private Integer weight;

    private String userName;

    private Date createAt;

    private static final long serialVersionUID = 1L;


}