package team.lmm.models;

import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author
 */
@Data
public class Consignation implements Serializable {
    private Integer id;

    @NotNull(message = "地址不能为空")
    private String address;

    private Integer uid;

    @NotNull(message = "联系电话不能为空")
    private String phone;

    @NotNull(message = "联系人姓名不能为空")
    private String contact;

    private BigDecimal lat;

    private BigDecimal lng;

    private String cityCode;

    /**
     * 0:洗窗帘
     */
    private Integer type = 0;

    /**
     * 90:已完成;0:待提交;1:待审核;10:审核通过;-1:已取消;-10:用户取消;-11:商户取消
     */
    private Integer status;

    private Integer flowId;

    /**
     * 受理店铺id
     */
    private String shopId;

    private Date createAt;

    private static final long serialVersionUID = 1L;
}