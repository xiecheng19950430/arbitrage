package team.lmm.models;

import lombok.Data;

import java.util.Date;

/**
 * @author: jf <for1988@126.com>
 * @date: 2017/1/11
 */

@Data
public class Transaction {

    private Integer id;
    private Integer accountId;
    private Integer inAmount;
    private Integer outAmount;
    private String remark;
    private Date createdAt;
    private String type;
    private String targetId;
    private Integer beforeTotal;
    private Integer afterTotal;
    private Integer beforeAmount;
    private Integer afterAmount;
    private Integer beforeFrozen;
    private Integer afterFrozen;
    private Integer beforeActive;
    private Integer afterActive;
}
