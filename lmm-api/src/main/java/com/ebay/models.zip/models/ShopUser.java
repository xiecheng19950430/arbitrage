package team.lmm.models;

import lombok.Data;

/**
 * Created by chenliang on 2017/2/7.
 */
@Data
public class ShopUser {

    private String shopId;
    private Integer userId;
    private Integer onLive;
    private String liveId;
    private Shop shop;
    private Integer shopOwner;

}
