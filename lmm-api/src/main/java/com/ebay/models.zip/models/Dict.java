package team.lmm.models;

import lombok.Data;

/**
 * @author: jf <for1988@126.com>
 * @date: 2016/12/8
 */

@Data
public class Dict {

    private Integer id;
    private String name;
    private Integer parentId;
    private Integer level;
    private Integer sortNo;
}
