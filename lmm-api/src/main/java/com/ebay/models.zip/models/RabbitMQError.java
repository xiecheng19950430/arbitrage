package team.lmm.models;

import lombok.Data;

import java.util.Date;

/**
 * Created by ldm on 2017/3/27.
 */
@Data
public class RabbitMQError {
    private String id;
    private String messageId;
    private String message;
    private Date createAt;
    private String queueName;
    private String errorMessage;
    private String stackTrace;
}
