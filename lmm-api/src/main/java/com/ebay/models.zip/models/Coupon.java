package team.lmm.models;

import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * @author: jf <for1988@126.com>
 * @date: 2016/12/31
 */

@Data
public class Coupon {

    private Integer ticketId;
    private String name;
    private Integer num;
    private Double money;

    private Double consumeMoney;
    private String range;
    private String rangeValue;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date start;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date end;
    private Date createDate;
    private String event;
    private String rangeNote;
    private String moneyNote;
    private Integer getRangeStart;
    private Integer getRangeEnd;
    private Integer getNum;

    private String state;
    private String lat;
    private String lng;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date receiveStart;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date receiveEnd;

    private Integer deleteFlag;

    private String area;
}
