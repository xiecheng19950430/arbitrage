package team.lmm.models;

import lombok.Data;

/**
 * @author: jf <for1988@126.com>
 * @date: 2016/12/28
 */

@Data
public class PushInfo {

    private Integer userId;
    private String pushId;
    private String deviceId;
    private String appType;
}
