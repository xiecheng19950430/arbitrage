package team.lmm.models;

import lombok.Data;

import java.util.Date;


/**
 * @author: jf <for1988@126.com>
 * @date: 2016/12/31
 */

@Data
public class UserCoupon {

    private Integer id;
    private Integer userId;
    private Integer ticketId;
    private Integer state;
    private Integer tradeId;
    private Date usedAt;

    private Coupon coupon;
}
