package team.lmm.models;

import lombok.Data;

import java.util.Date;

/**
 * @author: jf <for1988@126.com>
 * @date: 2016/12/20
 */

@Data
public class Trade {

    private Integer id;
    private Integer payType;
    private Integer state;
    private Date createdAt;
    private Date tradedAt;
    private Double amount;
    private String outTradeNo;
    private String tradeNo;
    private Integer uid;
    private String type;
    private Integer couponId;
    private Double platformBear;
    private Double platformDiscount;
    private Double vmDiscount;

    private Integer scope;
}
