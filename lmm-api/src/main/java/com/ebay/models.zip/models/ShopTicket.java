package team.lmm.models;

import lombok.Data;

/**
 * @author: jf <for1988@126.com>
 * @date: 2017/1/11
 */

@Data
public class ShopTicket {

    private Integer id;
    private Integer ticketId;
    private String shopId;
    private Integer bearMoney;
}
