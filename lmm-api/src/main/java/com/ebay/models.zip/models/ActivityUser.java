package team.lmm.models;

import lombok.Data;

import java.util.Date;

/**
 * Created by ldm on 2017/3/19.
 */
@Data
public class ActivityUser {
    private String id;
    private Integer userId;
    private String activityId;
    private Date createAt;
    private Integer successFlag;
    private String remark;
    private String remarkValue;

}
