package team.lmm.models;

import lombok.Data;

import java.util.Date;

/**
 * Created by chenliang on 2017/1/12.
 */
@Data
public class ShopMoneyRecord {
    private Integer moneyRecordId;
    private String shopId;
    private Integer recordAccountId;
    private Integer applyMoney;
    private Date applyDate;
    private String state;
    private String outTradeId;
    private String payType;
    private Date payDate;
    private Integer agentPayId;
}
