package team.lmm.models;

import lombok.Data;

import java.util.Date;

/**
 * Created by chenliang on 2017/1/11.
 */
@Data
public class Account {

    private Integer accountId;
    private String shopId;
    private Integer amount;//订单金额
    private Date createDate;
    private Date updateDate;
    private Integer frozenAmount;//冻结金额
    private Integer activeAmount;//可提现金额
    private Integer totalAmount;//总额

}
