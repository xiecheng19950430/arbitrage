package team.lmm.models;

import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * Created by chenliang on 2017/2/10.
 */
@Data
public class Images {

    private String id;
    private String outId;//商品，商家id
    @NotNull(message = "图片地址不能为空")
    private String imageUrl;
    private int sortNo;
    private int createUser;
    private String createTime;
    private int modifyUser;
    private String modifyTime;

}
