package team.lmm.models;

import lombok.Data;

import java.util.Date;

/**
 * Created by ldm on 2017/4/24.
 */
@Data
public class BrandShop {
    private Integer brandId;
    private String shopId;
    private Integer sort;
    private Date createAt;
}
