package team.lmm.models;

import lombok.Data;

/**
 * Created by ldm on 2017/4/11.
 */
@Data
public class ShopCategory {
    private Integer id;
    private String name;
    private String alias;
    private Integer areaDisplay;
}
