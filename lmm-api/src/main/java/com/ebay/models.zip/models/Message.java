package team.lmm.models;

import lombok.Data;

import java.util.Date;

/**
 * @author: jf <for1988@126.com>
 * @date: 2017/1/8
 */

@Data
public class Message {
    private Integer id;
    private String type;
    private String content;
    private String topic;
    private String description;
    private Date time;
    private Integer isRead;
    private Integer userId;
    private String url;
    private Integer pushState;
    private Integer messageType;
    private String img;
}
